# Hacienda delivery checklist

## 1. Brand foundation and responsive shell

- [ ] The website uses the supplied Hacienda palette, typography direction, thin gold hairline dividers, generous negative space, 4% film grain, no emoji in UI, and photographic vignettes.
- [ ] All client data lives in `/config/site.config.ts`; no real phone number or invented awards, reviews, history, or facts are introduced.
- [ ] Layouts are mobile-first at 360/390/768/1024/1440/1920, have touch targets of at least 44px, honor safe-area insets, use fluid `clamp()` type, and do not create horizontal scroll.
- [ ] `/manus-routes.json` lists every page route and excludes APIs/assets/system endpoints.

## 2. Marketing experience

- [ ] Home includes the full-bleed cinematic hero with gold wordmark, thin frame, View Menu and Order Now CTAs, signature dish story, live-grill section/fallback, cocktail teaser, sports/events strip, about teaser, info/map link, and footer.
- [ ] Scroll-driven transitions blend sections with gradients; text reveals use masked/staggered motion; reduced-motion mode degrades to fades.
- [ ] Every image has descriptive alt text and is lazy-loaded when not the hero.

## 3. Menu and dish presentation

- [ ] `/menu` is view-only with sticky category navigation, search, KES prices, `Ask staff` for TBC, dish imagery, and Order this actions.
- [ ] Dishes are transparent-background cutouts that float on dark surfaces with a ground shadow, editorial alternating layout, hover/in-view lift, and a mobile-friendly detail sheet.
- [ ] Generated imagery is marked illustrative in the footer.

## 4. Ordering and server quote

- [ ] `/order` supports item selection, per-item add-ons/notes, cart review, name/phone, table or pickup or delivery, table query parsing, and WhatsApp send.
- [ ] Cart persists with a guarded reducer/localStorage implementation.
- [ ] `/api/order/quote` recalculates totals from the server-side price table; the client never supplies trusted totals.
- [ ] WhatsApp output includes order ID, table/pickup/delivery, items, add-ons, quantities, totals, customer name, and phone using the configured placeholder destination.
- [ ] M-Pesa STK is not implemented in this phase and no secrets are stored in the repository.

## 5. QR and handoff

- [ ] `/qr` generates a root code and table codes 1–30 pointing to `/order?table=N`, with printable A5 table tents and downloadable PNG/PDF actions.
- [ ] `/order/confirmed` shows order summary and status.
- [ ] README explains how to edit config/prices and lists all placeholders and deferred work.
- [ ] Typecheck/build succeed and a production publication is confirmed before a live URL is reported.
