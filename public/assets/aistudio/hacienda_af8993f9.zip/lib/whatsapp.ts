import { formatKES } from '@/config/site.config';
import type { CartLine, CustomerDetails, Quote } from '@/lib/types';

export const makeOrderId = () => `HAC-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

export const formatWhatsAppMessage = (quote: Quote, details: CustomerDetails) => {
  const destination = details.mode === 'table' ? `Table ${details.table || '—'}` : details.mode === 'pickup' ? 'Pickup' : `Delivery — ${details.address || 'Address to confirm'}`;
  const itemLines = quote.lines.map((line) => {
    const extras = [...line.addOns.map((addon) => addon.name), line.cookingStyle].filter(Boolean).join(', ');
    return `• ${line.quantity} × ${line.item.name}${extras ? ` (${extras})` : ''} — ${formatKES(line.lineTotal)}`;
  }).join('\n');
  return [
    `HACIENDA ORDER ${quote.orderId}`,
    destination,
    '',
    itemLines,
    '',
    `Total: ${formatKES(quote.total)}`,
    `Name: ${details.name}`,
    `Phone: ${details.phone}`,
    details.mode === 'delivery' ? `Address: ${details.address || 'To confirm'}` : '',
    '',
    'Payment: Pay at table / on delivery',
  ].filter(Boolean).join('\n');
};

export const makeWhatsAppUrl = (number: string, message: string) => `https://wa.me/${number}?text=${encodeURIComponent(message)}`;

export const getLineTotal = (line: CartLine) => ((line.item.price ?? 0) + line.addOns.reduce((sum, addon) => sum + addon.price, 0)) * line.quantity;
