import type { CartLine } from '@/lib/types';

export type CartAction =
  | { type: 'add'; line: CartLine }
  | { type: 'decrement'; lineId: string }
  | { type: 'remove'; lineId: string }
  | { type: 'clear' }
  | { type: 'hydrate'; lines: CartLine[] };

export const cartReducer = (state: CartLine[], action: CartAction): CartLine[] => {
  if (action.type === 'hydrate') return action.lines;
  if (action.type === 'clear') return [];
  if (action.type === 'remove') return state.filter((line) => line.lineId !== action.lineId);
  if (action.type === 'decrement') {
    return state.flatMap((line) => line.lineId === action.lineId ? (line.quantity > 1 ? [{ ...line, quantity: line.quantity - 1 }] : []) : [line]);
  }
  const match = state.find((line) => line.lineId === action.line.lineId);
  return match ? state.map((line) => line.lineId === match.lineId ? { ...line, quantity: line.quantity + action.line.quantity } : line) : [...state, action.line];
};

export const cartTotal = (lines: CartLine[]) => lines.reduce((sum, line) => sum + ((line.item.price ?? 0) + line.addOns.reduce((a, b) => a + b.price, 0)) * line.quantity, 0);

export const makeLineId = (itemId: string, addOns: string[] = [], style = '') => [itemId, style, ...addOns.sort()].join('::');
