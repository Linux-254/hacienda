export default {
  logoUrl: "https://placehold.co/256x256/0D0B09/C9A24B.png?text=H",
};
