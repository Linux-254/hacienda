'use client';

import { createContext, useContext, useEffect, useMemo, useReducer, useState } from 'react';
import type { ReactNode } from 'react';
import type { MenuItem } from '@/config/site.config';
import { cartReducer, cartTotal, makeLineId } from '@/lib/cart';
import type { CartLine } from '@/lib/types';

const CartContext = createContext<null | { lines: CartLine[]; total: number; count: number; addItem: (item: MenuItem, addOns?: { name: string; price: number }[], cookingStyle?: string, note?: string) => void; decrement: (lineId: string) => void; remove: (lineId: string) => void; clear: () => void; table?: string }>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, dispatch] = useReducer(cartReducer, []);
  const [ready, setReady] = useState(false);
  const [table, setTable] = useState<string>();
  useEffect(() => {
    try { const stored = window.localStorage.getItem('hacienda-cart'); if (stored) dispatch({ type: 'hydrate', lines: JSON.parse(stored) }); } catch { /* localStorage can be disabled */ } finally { setReady(true); }
    const query = new URLSearchParams(window.location.search).get('table'); if (query) setTable(query);
  }, []);
  useEffect(() => { if (!ready) return; try { window.localStorage.setItem('hacienda-cart', JSON.stringify(lines)); } catch { /* storage is best effort */ } }, [lines, ready]);
  const value = useMemo(() => ({ lines, total: cartTotal(lines), count: lines.reduce((sum, line) => sum + line.quantity, 0), table, addItem: (item: MenuItem, addOns: { name: string; price: number }[] = [], cookingStyle?: string, note?: string) => dispatch({ type: 'add', line: { lineId: makeLineId(item.id, addOns.map((addon) => addon.name), cookingStyle), item, quantity: 1, addOns, cookingStyle, note } }), decrement: (lineId: string) => dispatch({ type: 'decrement', lineId }), remove: (lineId: string) => dispatch({ type: 'remove', lineId }), clear: () => dispatch({ type: 'clear' }) }), [lines, table]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() { const value = useContext(CartContext); if (!value) throw new Error('useCart must be used inside CartProvider'); return value; }
