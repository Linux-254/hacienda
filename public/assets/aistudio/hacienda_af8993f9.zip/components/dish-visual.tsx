import { siteConfig } from '@/config/site.config';

export function DishVisual({ src, alt, label, size = 'large', priority = false }: { src?: string; alt: string; label?: string; size?: 'small' | 'large'; priority?: boolean }) {
  return <div className={`dish-visual group relative ${size === 'small' ? 'h-44 w-44' : 'h-64 w-full max-w-[480px] sm:h-80'}`}>
    <div className="absolute bottom-[12%] left-1/2 h-7 w-[64%] -translate-x-1/2 rounded-[50%] bg-black/60 blur-xl transition duration-500 group-hover:w-[72%]" />
    {src ? <img src={src} alt={alt} loading={priority ? 'eager' : 'lazy'} className="relative h-full w-full object-contain drop-shadow-[0_22px_24px_rgba(0,0,0,.45)] transition duration-500 group-hover:-translate-y-2 group-hover:rotate-[1.5deg]" /> : <div className="relative grid h-full w-full place-items-center border border-dashed border-gold/20 bg-gradient-to-br from-walnut/35 to-black/10 text-center"><div><div className="editorial text-3xl text-cream/50">{label ?? 'Dish visual'}</div><div className="mt-2 text-[9px] uppercase tracking-[.2em] text-gold/60">{siteConfig.imageryNote}</div></div></div>}
  </div>;
}
