export function SectionLabel({ children, number }: { children: React.ReactNode; number?: string }) {
  return <div className="flex items-center gap-3"><span className="eyebrow">{number ?? 'Hacienda'}</span><span className="h-px w-12 bg-gold/50" /><span className="text-[10px] uppercase tracking-[.2em] text-cream/35">{children}</span></div>;
}
