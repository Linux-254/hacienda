import Link from 'next/link';
import { ArrowUpRight, MapPin } from 'lucide-react';
import { siteConfig } from '@/config/site.config';

export function Footer() {
  return <footer className="border-t border-[rgba(201,162,75,.25)] bg-[#0d0b09]">
    <div className="container-hacienda grid gap-12 py-16 md:grid-cols-[1.2fr_.8fr_.8fr] md:py-20">
      <div><div className="wordmark text-[15px] text-gold">Hacienda</div><p className="editorial mt-5 max-w-sm text-[25px] leading-[1.15] text-cream/80">{siteConfig.tagline}</p><p className="mt-7 max-w-md text-xs leading-6 text-cream/45">{siteConfig.imageryNote}</p></div>
      <div><p className="eyebrow">Find the fire</p><a href={siteConfig.mapUrl} target="_blank" rel="noreferrer" className="mt-5 flex items-start gap-3 text-sm leading-6 text-cream/75 hover:text-gold"><MapPin size={16} className="mt-1 shrink-0 text-gold" />{siteConfig.address}</a><p className="mt-3 text-sm text-cream/55">{siteConfig.hours}</p></div>
      <div><p className="eyebrow">Navigate</p><div className="mt-5 flex flex-col gap-3 text-sm text-cream/65"><Link href="/menu" className="hover:text-gold">Menu</Link><Link href="/order" className="hover:text-gold">Order</Link><Link href="/qr" className="hover:text-gold">QR table tents</Link><Link href="/info" className="hover:text-gold">Contact & info</Link></div></div>
    </div>
    <div className="container-hacienda hairline" />
    <div className="container-hacienda flex flex-col gap-3 py-5 text-[10px] uppercase tracking-[.15em] text-cream/35 sm:flex-row sm:items-center sm:justify-between"><span>© {new Date().getFullYear()} Hacienda Sports Bar & Grill</span><span>Illustrative imagery · Nairobi</span><a href="#top" className="inline-flex items-center gap-1 hover:text-gold">Back to top <ArrowUpRight size={12} /></a></div>
  </footer>;
}
