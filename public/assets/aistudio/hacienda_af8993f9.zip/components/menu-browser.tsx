'use client';

import { useMemo, useState } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { formatKES, siteConfig, type MenuCategory, type MenuItem } from '@/config/site.config';
import { useCart } from '@/components/cart-provider';
import { DishVisual } from '@/components/dish-visual';
import { SectionLabel } from '@/components/section-label';

const categories: MenuCategory[] = ['Main grill', 'Bites', 'Breakfast', 'Soups & hot drinks', 'Cocktails', 'Mocktails'];

export function MenuBrowser({ compact = false }: { compact?: boolean }) {
  const { addItem } = useCart();
  const [active, setActive] = useState<MenuCategory>('Main grill');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<MenuItem | null>(null);
  const filtered = useMemo(() => siteConfig.menu.filter((item) => item.category === active && item.name.toLowerCase().includes(query.toLowerCase())), [active, query]);
  return <div>
    <div className="sticky top-[72px] z-20 -mx-3 overflow-x-auto border-y border-[rgba(201,162,75,.16)] bg-[#0d0b09]/95 px-3 py-3 backdrop-blur-md sm:mx-0 sm:px-0"><div className="flex min-w-max items-center gap-2"><SlidersHorizontal size={14} className="mr-2 text-gold/70" />{categories.map((category) => <button key={category} type="button" onClick={() => setActive(category)} className={`min-h-10 px-3 text-[10px] font-semibold uppercase tracking-[.16em] transition ${active === category ? 'bg-gold text-black' : 'text-cream/55 hover:text-gold'}`}>{category}</button>)}</div></div>
    <div className="flex flex-col gap-4 py-8 sm:flex-row sm:items-center sm:justify-between"><div><SectionLabel number="Menu">{active}</SectionLabel><p className="mt-3 max-w-xl text-sm leading-6 text-cream/55">Choose a plate, then make it yours at the table. Items marked Ask staff are awaiting the latest confirmed price.</p></div><label className="flex min-h-12 items-center gap-3 border-b border-gold/30 sm:w-64"><Search size={16} className="text-gold/70" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search this section" aria-label="Search menu" className="w-full bg-transparent text-sm text-cream outline-none placeholder:text-cream/30" /></label></div>
    <div className="grid gap-x-14 gap-y-14 md:grid-cols-2">{filtered.slice(0, compact ? 4 : undefined).map((item, index) => <button key={item.id} type="button" onClick={() => setSelected(item)} className={`group text-left ${index % 2 ? 'md:translate-y-12' : ''}`}><div className="relative border-b border-[rgba(201,162,75,.16)] pb-5"><DishVisual src={item.image} alt={`${item.name} illustrative food photography`} label={item.name} size="small" /><div className="mt-3 flex items-start justify-between gap-3"><span className="display text-2xl text-cream transition group-hover:text-gold">{item.name}</span><span className="shrink-0 pt-1 font-mono text-xs text-gold">{item.price ? formatKES(item.price) : item.priceLabel}</span></div><p className="mt-2 max-w-sm text-xs leading-5 text-cream/50">{item.description}</p><span className="mt-4 inline-block text-[10px] font-bold uppercase tracking-[.18em] text-gold/70">{item.price ? 'Order this ↗' : 'Ask staff ↗'}</span></div></button>)}</div>
    {!filtered.length && <div className="border border-dashed border-gold/25 py-20 text-center text-sm text-cream/50">No plates match that search in this section.</div>}
    {selected && <DetailSheet item={selected} onClose={() => setSelected(null)} onAdd={() => { addItem(selected); setSelected(null); }} />}
  </div>;
}

function DetailSheet({ item, onClose, onAdd }: { item: MenuItem; onClose: () => void; onAdd: () => void }) {
  return <div className="fixed inset-0 z-50 grid items-end bg-black/70 p-3 sm:items-center sm:justify-center" role="dialog" aria-modal="true" aria-label={`${item.name} details`} onClick={onClose}><div className="max-h-[90vh] w-full max-w-lg overflow-y-auto border border-gold/30 bg-[#1a110d] p-5 sm:p-8" onClick={(event) => event.stopPropagation()}><div className="flex items-start justify-between"><div><p className="eyebrow">{item.category}</p><h2 className="display mt-2 text-3xl">{item.name}</h2></div><button type="button" aria-label="Close details" onClick={onClose} className="flex h-11 w-11 items-center justify-center border border-gold/25 text-gold"><X size={17} /></button></div><DishVisual src={item.image} alt={`${item.name} illustrative food photography`} label={item.name} /><p className="text-sm leading-7 text-cream/65">{item.description}</p>{item.tags?.length ? <div className="mt-5 flex flex-wrap gap-2">{item.tags.map((tag) => <span key={tag} className="border border-gold/25 px-3 py-2 text-[10px] uppercase tracking-[.12em] text-gold/75">{tag}</span>)}</div> : null}<div className="mt-7 flex items-center justify-between gap-4 border-t border-gold/20 pt-5"><span className="font-mono text-sm text-gold">{item.price ? formatKES(item.price) : item.priceLabel}</span>{item.price ? <button type="button" className="button-gold" onClick={onAdd}>Add to order</button> : <span className="text-[10px] uppercase tracking-[.15em] text-cream/45">Price to confirm</span>}</div></div></div>;
}
