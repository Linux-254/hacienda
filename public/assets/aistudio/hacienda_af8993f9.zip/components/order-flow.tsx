'use client';

import { useMemo, useState } from 'react';
import { ArrowRight, Minus, Plus, Trash2 } from 'lucide-react';
import { formatKES, siteConfig } from '@/config/site.config';
import { useCart } from '@/components/cart-provider';
import { getLineTotal, makeOrderId, formatWhatsAppMessage, makeWhatsAppUrl } from '@/lib/whatsapp';
import type { CustomerDetails, OrderMode, Quote } from '@/lib/types';

export function OrderFlow() {
  const { lines, total, count, decrement, addItem, remove, table, clear } = useCart();
  const [details, setDetails] = useState<CustomerDetails>({ name: '', phone: '', mode: table ? 'table' : 'pickup', table });
  const [status, setStatus] = useState<'idle' | 'sending' | 'error'>('idle');
  const [notice, setNotice] = useState('');
  const quote = useMemo<Quote>(() => ({ orderId: makeOrderId(), lines: lines.map((line) => ({ ...line, lineTotal: getLineTotal(line) })), subtotal: total, total }), [lines, total]);
  const setField = (field: keyof CustomerDetails, value: string) => setDetails((current) => ({ ...current, [field]: value }));
  const submit = async () => {
    if (!lines.length) return setNotice('Add at least one priced item to begin.');
    if (!details.name || !details.phone) return setNotice('Add your name and phone so the table knows who to find.');
    if (details.mode === 'table' && !details.table) return setNotice('Add a table number or switch to pickup.');
    setStatus('sending'); setNotice('');
    try {
      const response = await fetch('/api/order/quote', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ items: lines.map((line) => ({ itemId: line.item.id, quantity: line.quantity, addOns: line.addOns, cookingStyle: line.cookingStyle })) }) });
      if (!response.ok) throw new Error('quote');
      const serverQuote = await response.json() as Quote;
      const message = formatWhatsAppMessage({ ...serverQuote, orderId: quote.orderId }, details);
      window.location.href = makeWhatsAppUrl(siteConfig.whatsapp, message);
      clear();
    } catch { setStatus('error'); setNotice('We could not verify the order just now. Please try again.'); }
  };
  return <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
    <section className="border border-gold/20 bg-[#1a110d]/45 p-5 sm:p-8"><div className="flex items-end justify-between gap-4 border-b border-gold/20 pb-5"><div><p className="eyebrow">Step 01</p><h2 className="display mt-2 text-3xl">Your table, your call.</h2></div><span className="font-mono text-xs text-gold">{count} item{count === 1 ? '' : 's'}</span></div>{!lines.length ? <div className="py-16 text-center"><p className="editorial text-3xl text-cream/70">Your order is waiting by the fire.</p><a href="/menu" className="button-quiet mt-6">Browse the menu</a></div> : <div className="divide-y divide-gold/15">{lines.map((line) => <div key={line.lineId} className="flex gap-4 py-5"><div className="min-w-0 flex-1"><p className="display text-xl text-cream">{line.item.name}</p><p className="mt-1 text-xs text-cream/50">{[line.cookingStyle, ...line.addOns.map((addon) => addon.name)].filter(Boolean).join(' · ') || 'Served as listed'}</p><p className="mt-2 font-mono text-xs text-gold">{formatKES(getLineTotal(line))}</p></div><div className="flex items-center gap-1"><button type="button" aria-label={`Remove one ${line.item.name}`} onClick={() => decrement(line.lineId)} className="flex h-10 w-10 items-center justify-center border border-gold/20 text-gold"><Minus size={14} /></button><span className="w-8 text-center text-sm">{line.quantity}</span><button type="button" aria-label={`Add one ${line.item.name}`} onClick={() => addItem(line.item, line.addOns, line.cookingStyle, line.note)} className="flex h-10 w-10 items-center justify-center border border-gold/20 text-gold"><Plus size={14} /></button><button type="button" aria-label={`Remove ${line.item.name}`} onClick={() => remove(line.lineId)} className="ml-2 flex h-10 w-10 items-center justify-center text-cream/35 hover:text-amber"><Trash2 size={14} /></button></div></div>)}</div>}</section>
    <aside className="h-fit border border-gold/25 bg-[#24160f] p-5 sm:p-7"><p className="eyebrow">Step 02</p><h2 className="display mt-2 text-3xl">Send it to the room.</h2><div className="mt-6 space-y-4"><label className="block text-[10px] uppercase tracking-[.16em] text-cream/50">Name<input className="input-hacienda mt-2" value={details.name} onChange={(event) => setField('name', event.target.value)} placeholder="Your name" /></label><label className="block text-[10px] uppercase tracking-[.16em] text-cream/50">Phone<input className="input-hacienda mt-2" value={details.phone} onChange={(event) => setField('phone', event.target.value)} placeholder="07XX XXX XXX" /></label><div><span className="text-[10px] uppercase tracking-[.16em] text-cream/50">How are you dining?</span><div className="mt-2 grid grid-cols-3 gap-2">{(['table', 'pickup', 'delivery'] as OrderMode[]).map((mode) => <button key={mode} type="button" onClick={() => setDetails((current) => ({ ...current, mode }))} className={`min-h-11 border px-2 text-[10px] uppercase tracking-[.12em] ${details.mode === mode ? 'border-gold bg-gold text-black' : 'border-gold/20 text-cream/55'}`}>{mode}</button>)}</div></div>{details.mode === 'table' ? <label className="block text-[10px] uppercase tracking-[.16em] text-cream/50">Table number<input className="input-hacienda mt-2" value={details.table ?? ''} onChange={(event) => setField('table', event.target.value)} placeholder="e.g. 12" /></label> : null}{details.mode === 'delivery' ? <label className="block text-[10px] uppercase tracking-[.16em] text-cream/50">Delivery address<textarea className="input-hacienda mt-2 min-h-20 py-3" value={details.address ?? ''} onChange={(event) => setField('address', event.target.value)} placeholder="Add your delivery address" /></label> : null}</div><div className="mt-7 border-t border-gold/20 pt-5"><div className="flex items-center justify-between text-sm text-cream/60"><span>Order total</span><span className="font-mono text-gold">{formatKES(total)}</span></div><button type="button" onClick={submit} disabled={status === 'sending'} className="button-gold mt-5 w-full">{status === 'sending' ? 'Checking total…' : 'Send via WhatsApp'} <ArrowRight size={15} className="ml-3" /></button>{notice && <p className={`mt-4 text-xs leading-5 ${status === 'error' ? 'text-amber' : 'text-cream/60'}`}>{notice}</p>}<p className="mt-4 text-[10px] leading-5 text-cream/35">Payment is pay at table or on delivery. M-Pesa STK will be connected in phase 5.</p></div></aside>
  </div>;
}
