'use client';

import { motion, useReducedMotion } from 'framer-motion';
import type { ReactNode } from 'react';

export function Reveal({ children, delay = 0, className = '' }: { children: ReactNode; delay?: number; className?: string }) {
  const reduced = useReducedMotion();
  return <motion.div className={className} initial={reduced ? { opacity: 0 } : { opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .18 }} transition={{ duration: reduced ? .25 : .7, delay, ease: [0.22, 1, 0.36, 1] }}>{children}</motion.div>;
}

export function StaggerLines({ lines }: { lines: string[] }) {
  const reduced = useReducedMotion();
  return <div>{lines.map((line, index) => <motion.span key={`${line}-${index}`} className="block overflow-hidden" initial={reduced ? { opacity: 0 } : { opacity: 0, y: '100%' }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: reduced ? .2 : .75, delay: index * .06, ease: [0.22, 1, 0.36, 1] }}>{line}</motion.span>)}</div>;
}
