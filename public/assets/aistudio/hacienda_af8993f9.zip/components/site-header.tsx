'use client';

import Link from 'next/link';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { siteConfig } from '@/config/site.config';

const links = [
  { href: '/menu', label: 'Menu' },
  { href: '/events', label: 'Events' },
  { href: '/about', label: 'About' },
  { href: '/info', label: 'Info' },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-[rgba(201,162,75,.18)] bg-[#0d0b09]/85 backdrop-blur-md">
      <div className="container-hacienda flex h-[72px] items-center justify-between gap-8">
        <Link href="/" className="group flex items-center gap-3" onClick={() => setOpen(false)}>
          <span className="flex h-9 w-9 items-center justify-center border border-gold text-gold wordmark text-[11px]">H</span>
          <span className="hidden sm:block"><span className="block wordmark text-[13px] leading-none text-cream">Hacienda</span><span className="mt-1 block text-[9px] uppercase tracking-[.25em] text-gold/70">Sports Bar & Grill</span></span>
        </Link>
        <nav className="hidden items-center gap-7 md:flex" aria-label="Primary navigation">
          {links.map((link) => <Link key={link.href} href={link.href} className="text-[10px] font-semibold uppercase tracking-[.2em] text-cream/70 transition hover:text-gold">{link.label}</Link>)}
          <Link href="/order" className="button-gold min-h-[40px] px-4">Order now</Link>
        </nav>
        <button type="button" className="flex min-h-11 min-w-11 items-center justify-center border border-[rgba(201,162,75,.25)] text-gold md:hidden" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen((value) => !value)}>{open ? <X size={19} /> : <Menu size={19} />}</button>
      </div>
      {open && <div className="border-t border-[rgba(201,162,75,.18)] bg-[#0d0b09] md:hidden"><nav className="container-hacienda flex flex-col gap-1 py-4" aria-label="Mobile navigation">{links.map((link) => <Link key={link.href} href={link.href} onClick={() => setOpen(false)} className="flex min-h-12 items-center border-b border-[rgba(201,162,75,.12)] text-[11px] font-semibold uppercase tracking-[.2em] text-cream/75">{link.label}</Link>)}<Link href="/order" onClick={() => setOpen(false)} className="button-gold mt-3">Order now</Link></nav></div>}
    </header>
  );
}
