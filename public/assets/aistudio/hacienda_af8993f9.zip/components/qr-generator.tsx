'use client';

import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Download, Printer } from 'lucide-react';
import { siteConfig } from '@/config/site.config';

export function QRGenerator() {
  const [origin, setOrigin] = useState('');
  const [table, setTable] = useState('1');
  const [src, setSrc] = useState('');
  useEffect(() => setOrigin(window.location.origin), []);
  useEffect(() => { if (!origin) return; QRCode.toDataURL(`${origin}/order?table=${table}`, { width: 720, margin: 2, color: { dark: '#0D0B09', light: '#F3E9D2' } }).then(setSrc); }, [origin, table]);
  const download = () => { if (!src) return; const link = document.createElement('a'); link.href = src; link.download = `hacienda-table-${table}.png`; link.click(); };
  return <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
    <div className="print-sheet border border-gold/25 bg-[#f3e9d2] p-8 text-[#0d0b09] sm:p-12"><div className="mx-auto flex max-w-sm flex-col items-center text-center"><span className="wordmark text-[15px] tracking-[.28em]">Hacienda</span><span className="mt-2 text-[9px] uppercase tracking-[.28em] text-[#4a2e1f]/70">Sports Bar & Grill</span><div className="my-8 h-px w-20 bg-[#c9a24b]" />{src ? <img src={src} alt={`QR code for table ${table}`} className="h-56 w-56 sm:h-64 sm:w-64" /> : <div className="grid h-56 w-56 place-items-center bg-[#e9dcc0] text-xs text-[#4a2e1f]/60">Preparing QR…</div>}<p className="mt-7 font-serif text-3xl">Scan to order</p><p className="mt-2 text-xs uppercase tracking-[.22em] text-[#4a2e1f]/65">Table {table}</p><p className="mt-8 text-xs leading-5 text-[#4a2e1f]/70">{siteConfig.tagline}</p></div></div>
    <aside className="no-print h-fit border border-gold/20 bg-[#1a110d]/65 p-5 sm:p-7"><p className="eyebrow">Printable table tent</p><h2 className="display mt-2 text-3xl">Choose a table.</h2><label className="mt-6 block text-[10px] uppercase tracking-[.16em] text-cream/50">Table number<input type="number" min="1" max="30" className="input-hacienda mt-2" value={table} onChange={(event) => setTable(String(Math.min(30, Math.max(1, Number(event.target.value) || 1))))} /></label><div className="mt-5 grid gap-3"><button type="button" className="button-gold w-full" onClick={download}><Download size={15} className="mr-2" /> Download PNG</button><button type="button" className="button-quiet w-full" onClick={() => window.print()}><Printer size={15} className="mr-2" /> Print / save PDF</button></div><p className="mt-5 text-xs leading-5 text-cream/40">The QR codes for tables 1–30 all point to `/order?table=N`. Change the number to print each tent.</p></aside>
  </div>;
}
