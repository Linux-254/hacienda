import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}', './config/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        black: '#0D0B09',
        espresso: '#2B1A12',
        walnut: '#4A2E1F',
        gold: '#C9A24B',
        amber: '#D9822B',
        cream: '#F3E9D2',
      },
    },
  },
  plugins: [],
};

export default config;
