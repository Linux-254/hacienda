import type { Metadata } from 'next';
import './globals.css';
import { siteConfig } from '@/config/site.config';
import { SiteHeader } from '@/components/site-header';
import { Footer } from '@/components/footer';

export const metadata: Metadata = {
  title: {
    default: siteConfig.name,
    template: `%s — ${siteConfig.name}`,
  },
  description: `${siteConfig.tagline} ${siteConfig.address}.`,
  metadataBase: new URL('https://hacienda-sports-bar-grill.example'),
  openGraph: {
    title: siteConfig.name,
    description: siteConfig.tagline,
    type: 'website',
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className="site-grain"><SiteHeader />{children}<Footer /></body></html>;
}
