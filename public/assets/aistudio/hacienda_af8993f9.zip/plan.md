# Hacienda Sports Bar & Grill — implementation plan

## Design read

- **Artifact:** responsive multi-route restaurant website with QR ordering journey.
- **Audience:** Nairobi diners, sports-night groups, takeaway customers, and table guests scanning a QR code.
- **Visual language:** modern old-money steakhouse — dark walnut, brass, candlelight, editorial serif typography, and restrained motion.
- **Mode:** greenfield build.
- **Visual variance:** 8/10. The experience should feel bespoke rather than template-like.
- **Motion intensity:** 7/10 on desktop, 3/10 under reduced motion.
- **Information density:** 5/10 on marketing pages, 8/10 on menu/order pages.
- **Asset dependence:** 8/10; signature food and cocktail cutouts are central to the menu story.
- **Brand fidelity:** 9/10; all client values flow from config.

## Design decisions

- **Design movement:** editorial hospitality / modern East African steakhouse.
- **Core principles:** cinematic warmth, transparent dish cutouts, generous negative space, and quiet confidence.
- **Color philosophy:** black and espresso create a low-light stage; walnut and amber suggest timber, fire, and grill heat; gold is reserved for actions, prices, rules, and moments of emphasis; cream keeps long-form text readable.
- **Layout paradigm:** vertical editorial chapters with hairline dividers and alternating image/text compositions instead of boxed card grids.
- **Signature elements:** brass rule lines, framed hero wordmark, and food objects that float over an atmospheric surface with a soft ground shadow.
- **Interaction philosophy:** motion explains focus and sequence; dish hover/lift is tactile; cart state is always visible and one-hand friendly.
- **Animation:** smooth 700–1200ms hero reveal, 320–650ms section transitions, staggered text masks, slow Ken Burns on hero imagery, and CSS ember/sizzle fallbacks. All nonessential motion fades or stops under `prefers-reduced-motion`.
- **Typography:** Cormorant Garamond for editorial italic accents, Playfair Display for headlines, Inter for body/UI, Cinzel for the wide-cap wordmark.
- **Brand essence:** Nairobi’s late-night grill room for people who like their sport loud, their fire slow, and their table easy. Personality: assured, warm, unhurried.
- **Brand voice:** concise, sensory, and never over-explained. Example lines: “A good table begins at the fire.” / “Stay for the match. Order for the table.”
- **Wordmark concept:** `HACIENDA` in spaced Cinzel caps with a small brass monogram rule, used as a framed seal rather than a logo image.
- **Signature brand color:** Hacienda Gold `#C9A24B`.

## Implementation approach

- Next.js 14 App Router with TypeScript, Tailwind CSS, Framer Motion, qrcode, and lucide-react.
- `/config/site.config.ts` owns client information, menu data, add-ons, features, and generated image URLs.
- Server route `/api/order/quote` accepts item IDs and quantities, recalculates totals from the server-side catalog, and returns a quote. No M-Pesa is implemented until explicitly requested.
- Client hooks own cart persistence, table query parsing, reduced-motion detection, and WhatsApp message formatting.
- Marketing pages share `SiteHeader`, `Footer`, `Reveal`, `DishVisual`, `SectionLabel`, and `PageIntro`; menu/order use the same tokens with denser utility controls.
- `/qr` uses the qrcode package in the browser to render root and table 1–30 codes; print styling creates A5 table tents.
- Public images use the generated Managed Storage URLs directly so they can swap from generating placeholders to completed imagery without source edits.

## Project structure

```text
app/                    App Router pages and route handlers
  api/order/quote/      server-side quote endpoint
  about/ events/ info/ menu/ order/ qr/ order/confirmed/
components/             shared layout, motion, dish, menu, cart, QR components
config/                 config-driven client and menu source of truth
lib/                    types, cart utilities, WhatsApp and QR helpers
public/                 route manifest, favicon, static fallback assets
```

## Delivery workflow

1. Scaffold and install pinned dependencies.
2. Build config, tokens, shared layout, and route manifest.
3. Implement home, menu, order, QR, info, events, about, and confirmation routes.
4. Run typecheck/build, inspect route manifest and source-level acceptance clauses.
5. Save a checkpoint, publish, and attempt the requested GitHub canonical transfer only through the managed repository flow.
6. Document placeholders and phase-5 M-Pesa deferral in README.
